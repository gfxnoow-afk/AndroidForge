# ColorOS Style Launcher — starter project

A lightweight ColorOS-inspired Android launcher starter for Samsung Galaxy A34 / Android 12+.

## Included
- HOME/default-launcher activity declaration
- Clock and date home screen
- App shortcuts for common apps when installed
- App drawer with search
- Swipe up to open app drawer
- Rounded icon tiles and animated home/drawer transition
- Opens installed apps through Android's package manager

## Build an APK
1. Install Android Studio on a computer.
2. Open this project folder (`ColorOS_Style_Launcher`) in Android Studio.
3. Let Gradle sync and install the Android SDK Platform 35 if prompted.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be created at:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Transfer the APK to the phone and install it. Android may ask you to allow installs from that source.
7. Press Home and select **ColorOS Style Launcher**. If needed, go to Settings > Apps > Default apps > Home app.

## Notes / limitations
- This is an initial starter build, not a complete OEM ColorOS replacement.
- It cannot replace Samsung's system Recents screen, notification shade, lock screen, or system animations.
- App opening transitions are partly controlled by Android and each app. The launcher animates its own home/app-drawer transition.
- App visibility uses `QUERY_ALL_PACKAGES` so the app drawer can list installed apps. Keep this permission in mind if you later publish the app.
- The build needs Android Studio/Gradle and an Android SDK. No compiled APK is included in this source archive.
