package com.rocky.colorlauncher

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class AppEntry(
    val label: String,
    val packageName: String,
    val icon: android.graphics.drawable.Drawable
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(244, 245, 249)
        window.navigationBarColor = android.graphics.Color.rgb(244, 245, 249)
        setContent { ColorLauncherApp() }
    }
}

@Composable
private fun ColorLauncherApp() {
    val context = LocalContext.current
    val pm = context.packageManager
    var showDrawer by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var now by remember { mutableStateOf(Date()) }
    var dragTotal by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(15_000)
        }
    }

    val apps = remember {
        pm.getInstalledApplications(0)
            .mapNotNull { info ->
                val launch = pm.getLaunchIntentForPackage(info.packageName)
                if (launch == null || info.packageName == context.packageName) null
                else AppEntry(
                    label = pm.getApplicationLabel(info).toString(),
                    packageName = info.packageName,
                    icon = pm.getApplicationIcon(info)
                )
            }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    val filtered = apps.filter { it.label.contains(query, ignoreCase = true) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF5267C9),
            background = Color(0xFFF4F5F9),
            surface = Color.White
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFFF9FAFF), Color(0xFFE9ECF8), Color(0xFFF4F5F9))
                    )
                )
                .pointerInput(showDrawer) {
                    detectVerticalDragGestures(
                        onVerticalDrag = { _, amount -> dragTotal += amount },
                        onDragEnd = {
                            if (dragTotal < -35f) showDrawer = true
                            if (dragTotal > 45f) {
                                if (showDrawer) query = "" else showDrawer = false
                            }
                            dragTotal = 0f
                        }
                    )
                }
        ) {
            AnimatedContent(
                targetState = showDrawer,
                transitionSpec = {
                    (fadeIn(tween(190)) + scaleIn(initialScale = 0.97f, animationSpec = tween(190))) togetherWith
                        (fadeOut(tween(130)) + scaleOut(targetScale = 1.02f, animationSpec = tween(130)))
                },
                label = "home-drawer-transition"
            ) { drawer ->
                if (drawer) {
                    AppDrawer(
                        apps = filtered,
                        query = query,
                        onQuery = { query = it },
                        onLaunch = { app ->
                            val intent = pm.getLaunchIntentForPackage(app.packageName)
                            if (intent != null) {
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                context.startActivity(intent)
                            }
                        },
                        onBack = {
                            showDrawer = false
                            query = ""
                        }
                    )
                } else {
                    HomeScreen(
                        now = now,
                        onOpenDrawer = { showDrawer = true },
                        onLaunchApp = { packageName ->
                            pm.getLaunchIntentForPackage(packageName)?.let {
                                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                context.startActivity(it)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    now: Date,
    onOpenDrawer: () -> Unit,
    onLaunchApp: (String) -> Unit
) {
    val context = LocalContext.current
    val pm = context.packageManager
    val shortcuts = remember {
        listOf(
            "com.android.chrome",
            "com.google.android.gm",
            "com.google.android.youtube",
            "com.whatsapp",
            "com.android.settings",
            "com.google.android.apps.maps",
            "com.google.android.dialer",
            "com.samsung.android.messaging"
        ).mapNotNull { pkg ->
            try {
                val info = pm.getApplicationInfo(pkg, 0)
                if (pm.getLaunchIntentForPackage(pkg) == null) null else AppEntry(
                    pm.getApplicationLabel(info).toString(), pkg, pm.getApplicationIcon(info)
                )
            } catch (_: Exception) { null }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 22.dp, vertical = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now),
                    color = Color(0xFF666B7A), fontSize = 14.sp
                )
                Text(
                    SimpleDateFormat("HH:mm", Locale.getDefault()).format(now),
                    color = Color(0xFF202437), fontSize = 48.sp, fontWeight = FontWeight.Light
                )
            }
            Surface(
                shape = CircleShape,
                color = Color.White.copy(alpha = 0.85f),
                shadowElevation = 2.dp,
                modifier = Modifier.size(48.dp).clickable {
                    onLaunchApp("com.android.settings")
                }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color(0xFF414A78))
                }
            }
        }

        Spacer(Modifier.height(22.dp))

        Surface(
            color = Color.White.copy(alpha = 0.82f),
            shape = RoundedCornerShape(26.dp),
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth().height(112.dp)
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.Center) {
                Text("Hello there", fontSize = 14.sp, color = Color(0xFF74798A))
                Text("Make today yours.", fontSize = 23.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF252A40))
                Text("Swipe up to open apps", fontSize = 12.sp, color = Color(0xFF777D91))
            }
        }

        Spacer(Modifier.weight(1f))

        Text("Favourites", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF34394F))
        Spacer(Modifier.height(12.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.heightIn(max = 240.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(shortcuts) { app ->
                AppIcon(app = app, onClick = { onLaunchApp(app.packageName) })
            }
        }

        Spacer(Modifier.height(18.dp))

        Surface(
            shape = RoundedCornerShape(30.dp),
            color = Color.White.copy(alpha = 0.88f),
            shadowElevation = 5.dp,
            modifier = Modifier.fillMaxWidth().height(76.dp).clickable { onOpenDrawer() }
        ) {
            Row(
                Modifier.fillMaxSize().padding(horizontal = 22.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF5663A7))
                Spacer(Modifier.width(10.dp))
                Text("Search apps", color = Color(0xFF666B7A), fontSize = 15.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            "Swipe up for all apps",
            modifier = Modifier.align(Alignment.CenterHorizontally).clickable { onOpenDrawer() }.padding(6.dp),
            color = Color(0xFF73798D), fontSize = 12.sp
        )
    }
}

@Composable
private fun AppDrawer(
    apps: List<AppEntry>,
    query: String,
    onQuery: (String) -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 18.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("All apps", fontSize = 29.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF252A40), modifier = Modifier.weight(1f))
            TextButton(onClick = onBack) { Text("Home") }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = query,
            onValueChange = onQuery,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(22.dp),
            placeholder = { Text("Search apps") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }
        )
        Spacer(Modifier.height(14.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            contentPadding = PaddingValues(bottom = 18.dp)
        ) {
            items(apps, key = { it.packageName }) { app ->
                AppIcon(app = app, onClick = { onLaunch(app) })
            }
        }
    }
}

@Composable
private fun AppIcon(app: AppEntry, onClick: () -> Unit) {
    var pressed by remember { mutableStateOf(false) }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth().clickable {
            pressed = true
            onClick()
        }
    ) {
        Surface(
            shape = RoundedCornerShape(19.dp),
            color = Color.White,
            shadowElevation = 3.dp,
            modifier = Modifier.size(58.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                androidx.compose.foundation.Image(
                    painter = androidx.compose.ui.graphics.painter.DrawablePainter(app.icon),
                    contentDescription = app.label,
                    modifier = Modifier.padding(7.dp).fillMaxSize()
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            app.label,
            color = Color(0xFF363B4F),
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
